import React, { useState } from "react";

const initialAirdrops = [
  { id: 1, title: "Airdrop A", category: "New", votes: 10, created_at: "2025-06-09T12:00:00Z" },
  { id: 2, title: "Airdrop B", category: "Free", votes: 5, created_at: "2025-06-08T12:00:00Z" },
  { id: 3, title: "Airdrop C", category: "Hot", votes: 20, created_at: "2025-06-07T12:00:00Z" }
];

function App() {
  const [expanded, setExpanded] = useState("New");

  const sortedNew = initialAirdrops
    .filter(a => a.category === "New")
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  const toggleSection = (section) => {
    setExpanded(expanded === section ? null : section);
  };

  return (
    <div style={{backgroundColor: "#121212", color: "#eee", minHeight: "100vh", padding: "20px", fontFamily: "Arial"}}>
      <h1>Airdrop Fun</h1>

      <Section
        title="New Airdrop"
        isExpanded={expanded === "New"}
        onToggle={() => toggleSection("New")}
        items={sortedNew}
      />

      <Section
        title="Free Airdrop"
        isExpanded={expanded === "Free"}
        onToggle={() => toggleSection("Free")}
        items={initialAirdrops.filter(a => a.category === "Free")}
      />

      <Section
        title="Hot Airdrop"
        isExpanded={expanded === "Hot"}
        onToggle={() => toggleSection("Hot")}
        items={initialAirdrops.filter(a => a.category === "Hot")}
      />
    </div>
  );
}

function Section({ title, isExpanded, onToggle, items }) {
  return (
    <div style={{ marginBottom: 20, backgroundColor: "rgba(255,255,255,0.05)", borderRadius: 8, padding: 10 }}>
      <h2 onClick={onToggle} style={{ cursor: "pointer", userSelect: "none" }}>
        {title} {isExpanded ? "▲" : "▼"}
      </h2>
      {isExpanded && (
        <ul>
          {items.map(item => (
            <li key={item.id} style={{ marginBottom: 8 }}>
              {item.title} - Votes: {item.votes}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default App;